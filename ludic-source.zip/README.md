# Ludic Linux

**A gaming desktop that still feels like your PC.**

Ludic is a desktop-first Linux distribution concept for PC gaming. Its main edition starts with KDE Plasma and the gaming-ready Fedora Atomic system from Bazzite. An experimental Lite edition adds a separate, minimal LXQt desktop for systems with very little memory.

## What you get

- KDE Plasma desktop and Steam from the Bazzite base.
- A choice of AMD/Intel, NVIDIA, or modern NVIDIA graphics images.
- Heroic Games Launcher for Epic, GOG, and Amazon libraries, plus ProtonUp-Qt for managing community compatibility tools.
- Atomic system updates with a previous deployment available for rollback.
- A custom Ludic wallpaper and operating-system name.
- A live preview ISO that boots to the desktop without starting an installation.
- A separate network installer ISO for people who decide to install later.
- An experimental Lite image with a 1 GB idle-desktop target, compressed swap, and a lightweight LXQt desktop.

Ludic does not promise that every game works. Game publishers control Linux and anti-cheat support; check the game’s current compatibility before switching your main PC.

## Download the preview

[Download the Ludic Lite live preview ISO](https://github.com/bobby47273491287/ludic-linux/releases/download/ludic-lite-preview/ludic-lite-live.iso) · [SHA-256 checksum](https://github.com/bobby47273491287/ludic-linux/releases/download/ludic-lite-preview/ludic-lite-live.iso.sha256) · [Release notes](https://github.com/bobby47273491287/ludic-linux/releases/tag/ludic-lite-preview)

The ISO boots a temporary LXQt desktop for testing in a virtual machine or from USB. It has no installer. Ludic Lite's 1 GB idle-desktop target is experimental, unmeasured, and not a minimum hardware requirement. This is an early preview, not a finished or hardware-validated operating system.

## Project status

This is an experimental prototype. The Lite live preview is built on GitHub Actions and published as a preview release. The separate installable system images still need their signed image build configured; see [Build and release](docs/BUILD.md).

## Hardware flavors

| Build | Choose it for |
| --- | --- |
| ludic | AMD or Intel graphics |
| ludic-nvidia | NVIDIA graphics using the standard driver image |
| ludic-nvidia-open | Supported newer NVIDIA GPUs using the open kernel module |
| ludic-lite | Experimental LXQt desktop, AMD/Intel graphics, low-memory use |

### Memory expectations

The 1 GB figure is an experimental target for how much physical RAM the installed Lite desktop uses while idle after startup, on a PC that has more RAM available. It is not a hardware minimum, and has not yet been measured or guaranteed. Lite keeps game launchers available from Flathub without installing them on first boot, so the desktop can stay small; opening a browser or game launcher uses additional memory, and running a modern local PC game in 1 GB of used RAM is generally impractical. Under severe memory pressure, the Lite edition may close the largest app to keep the desktop responsive. The standard Bazzite-based gaming desktop still needs substantially more memory; Bazzite lists 8 GB as its minimum for gaming. See [Bazzite's hardware requirements](https://docs.bazzite.gg/Gaming/Hardware_compatibility_for_gaming/).

The NVIDIA open-module build is for Turing-generation GPUs and newer. If you are unsure which image fits your GPU, check [Bazzite’s current image guide](https://docs.bazzite.gg/General/FAQ/) before installing.

## Build it

1. The source is available as [`ludic-source.zip`](https://github.com/bobby47273491287/ludic-linux/raw/refs/heads/main/ludic-source.zip); the live-preview workflow is in [`.github/workflows/build-lite-preview.yml`](https://github.com/bobby47273491287/ludic-linux/blob/main/.github/workflows/build-lite-preview.yml).
2. Generate a Cosign key pair. Keep the private key private; add it to repository Actions secrets as SIGNING_SECRET. Make the public key available to the build as COSIGN_PUBLIC_KEY. More detail is in [Build and release](docs/BUILD.md).
3. Run **Build Ludic images** in the Actions tab. The workflow publishes the standard system images and the Lite image to GitHub Container Registry.
4. The Lite live preview workflow builds an unsigned local image without publishing it, then publishes the ISO and SHA-256 checksum to the [Ludic Lite preview release](https://github.com/bobby47273491287/ludic-linux/releases/tag/ludic-lite-preview). If a future ISO exceeds GitHub's per-file release limit, the workflow keeps a one-day Actions artifact instead.
5. For a permanent install, run **Build a Ludic installer** and choose Lite or a standard graphics flavor. You can install it in a virtual machine to try the permanent desktop without changing your PC's drive.

For live preview details, local Linux builds, and the image-based install flow, see [Build and release](docs/BUILD.md) and [Try or install Ludic](docs/INSTALL.md).

## Website

A standalone static website is included at the project root and published with GitHub Pages. It links directly to the [Ludic Lite live preview ISO](https://github.com/bobby47273491287/ludic-linux/releases/download/ludic-lite-preview/ludic-lite-live.iso). The site is designed to stay lightweight and does not load third-party fonts or tracking scripts.

## Design

Ludic uses a graphite background with cool cyan light and restrained warm accents. KDE stays familiar and keyboard-and-mouse first; the system is not forced into a console interface. See the [design brief](docs/DESIGN.md) and the [wallpaper preview](files/system/usr/share/backgrounds/ludic/ludic-aurora.svg).

## Known limits

- This prototype targets x86_64 PCs. ARM PCs and handheld-specific interfaces are outside the first release.
- The installer needs a working internet connection to retrieve the selected system image.
- The live preview is temporary: changes made during the session are lost at shutdown. It is for checking the desktop and apps; game performance in a live session will not match an installed system.
- The Ludic wallpaper is included in the image for selection from KDE’s wallpaper settings; automatic default-wallpaper selection is later work.
- Game compatibility depends on each title, launcher, graphics driver, and anti-cheat configuration.
- The first release inherits the Bazzite installer and much of its desktop behavior. Ludic-specific installer screens and a dedicated settings app are later work.
- Ludic Lite is an experimental, AMD/Intel-only desktop. Its 1 GB installed-idle target must be measured on real hardware before it can be advertised as a guaranteed figure.
- Ludic is an independent community project, not an official Fedora, Bazzite, Valve, Epic, GOG, or Amazon product.

## Upstream references

- [Bazzite image flavors and hardware guidance](https://docs.bazzite.gg/General/FAQ/)
- [Bazzite guidance for custom images](https://docs.bazzite.gg/Advanced/creating_custom_image/)
- [BlueBuild repository setup](https://blue-build.org/how-to/setup/)
- [BlueBuild installer ISO guide](https://blue-build.org/how-to/generate-iso/)
- [Heroic Games Launcher source](https://github.com/Heroic-Games-Launcher/HeroicGamesLauncher)
- [ProtonUp-Qt source](https://github.com/DavidoTek/ProtonUp-Qt)

## License

The Ludic-specific configuration and branding in this repository are offered under the MIT License. Upstream components retain their own licenses and trademarks.
